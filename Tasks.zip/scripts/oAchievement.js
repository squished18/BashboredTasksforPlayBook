function oAchievement()
{
    this.iAchievementID = 0;
    this.sDescription = "";
    this.dCompleted = new Date(0);
    this.iDayValue = 0;
}; // end oAchievement()