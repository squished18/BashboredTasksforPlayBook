function oArchive()
{
    this.iChecklistID = -1;
    this.dCompleted = new Date(0);
    this.sEntry = "";
};